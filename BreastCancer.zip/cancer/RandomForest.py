# Import libraries for feature selection
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import RFE
from sklearn.model_selection import train_test_split
import pandas as pd

# Load the balanced data
df = pd.read_csv("Balanced_CancerData.csv")

# Separate features (X) and target variable (y)
X = df.drop('diagnosis', axis=1)
y = df['diagnosis']

# Step 1: Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 2: Apply Random Forest to check feature importance
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)

# Display feature importance
feature_importance = pd.DataFrame(rf.feature_importances_, index=X.columns, columns=["Importance"])
print("Feature Importance:")
print(feature_importance)

# Step 3: Select features using RFE (Recursive Feature Elimination)
# We will use the Random Forest model as the estimator for RFE
rfe = RFE(estimator=rf, n_features_to_select=10)  # Select top 10 features
rfe.fit(X_train, y_train)

# Get selected features
selected_features = X.columns[rfe.support_]
print("\nSelected Features using RFE:")
print(selected_features)

# Step 4: Evaluate model using selected features
X_train_selected = X_train[selected_features]
X_test_selected = X_test[selected_features]

# Train Random Forest model with selected features
rf_selected = RandomForestClassifier(n_estimators=100, random_state=42)
rf_selected.fit(X_train_selected, y_train)

# Check accuracy on test set
accuracy = rf_selected.score(X_test_selected, y_test)
print("\nModel Accuracy with Selected Features: {:.4f}".format(accuracy))
