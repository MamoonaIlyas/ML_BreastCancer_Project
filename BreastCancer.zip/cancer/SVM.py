import pandas as pd
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, cross_validate
from sklearn.metrics import (
    confusion_matrix, classification_report, ConfusionMatrixDisplay,
    roc_curve, auc, precision_recall_curve, matthews_corrcoef
)

# Step 1: Load the balanced dataset after feature selection
df = pd.read_csv("Balanced_CancerData.csv")

# Features selected after feature selection (using RFE or other methods)
selected_features = [
    'texture_mean', 'concavity_mean', 'concave points_mean', 'area_se',
    'radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst',
    'concavity_worst', 'concave points_worst'
]

# Step 2: Separate features and target
X = df[selected_features]  # Use only selected features
y = df['diagnosis']  # Target variable

# ----- Part 1: Cross-Validation Results -----
print("\n=== SVM Model - 10-Fold Cross-Validation Results ===")
model_cv = SVC(probability=True)  # Enable probability for ROC/PR later
scoring = ['accuracy', 'precision', 'recall', 'f1']
scores = cross_validate(model_cv, X, y, cv=10, scoring=scoring)
for metric in scoring:
    print(f"{metric.capitalize()}: {scores[f'test_{metric}'].mean():.4f}")

# ----- Part 2: Train/Test Evaluation and Full Metrics -----
# Step 3: Fixed 80/20 train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Step 4: Train model
model = SVC(probability=True)
model.fit(X_train, y_train)

# Step 5: Predict
y_pred = model.predict(X_test)
y_pred_prob = model.predict_proba(X_test)[:, 1]

# Step 6: Confusion Matrix & Classification Report
cm = confusion_matrix(y_test, y_pred)
print("\n=== Confusion Matrix ===\n", cm)
print("\n=== Classification Report ===\n", classification_report(y_test, y_pred))

# Step 7: Extra Metrics (Specificity, NPV, FPR, FNR, MCC)
tn, fp, fn, tp = cm.ravel()
specificity = tn / (tn + fp)
npv = tn / (tn + fn)
fpr_metric = fp / (fp + tn)
fnr_metric = fn / (fn + tp)
mcc = matthews_corrcoef(y_test, y_pred)

print(f"Specificity: {specificity:.4f}")
print(f"Negative Predictive Value (NPV): {npv:.4f}")
print(f"False Positive Rate (FPR): {fpr_metric:.4f}")
print(f"False Negative Rate (FNR): {fnr_metric:.4f}")
print(f"Matthews Correlation Coefficient (MCC): {mcc:.4f}")

# Step 8: Confusion Matrix Visualization
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Benign (0)", "Malignant (1)"])
disp.plot(cmap='Blues')
plt.title("SVM - Confusion Matrix")
plt.show()

# Step 9: ROC Curve
fpr, tpr, _ = roc_curve(y_test, y_pred_prob)
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (AUC = {roc_auc:.4f})')
plt.plot([0, 1], [0, 1], color='navy', lw=1, linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('SVM - ROC Curve')
plt.legend(loc="lower right")
plt.grid(True)
plt.show()

# Step 10: Precision–Recall Curve
precision, recall, _ = precision_recall_curve(y_test, y_pred_prob)
pr_auc = auc(recall, precision)

plt.figure()
plt.plot(recall, precision, color='green', lw=2, label=f'PR curve (AUC = {pr_auc:.4f})')
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('SVM - Precision-Recall Curve')
plt.legend(loc="lower left")
plt.grid(True)
plt.show()
