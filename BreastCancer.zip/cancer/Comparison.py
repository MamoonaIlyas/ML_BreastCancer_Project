import pandas as pd
import matplotlib.pyplot as plt

# Data for models comparison, excluding CNN
data = {
    'Model': ['Logistic Regression', 'SVM', 'Random Forest', 'KNN', 'ANN (original)', 'PSO+ANN'],
    'Accuracy': [0.9583, 0.9650, 0.9617, 0.9717, 0.9745, 0.9917],
    'Precision': [0.9610, 0.9736, 0.9589, 0.9620, 0.9600, 1.0000],
    'Recall': [0.9567, 0.9567, 0.9667, 0.9833, 0.9677, 0.9848],
    'F1 Score': [0.9583, 0.9646, 0.9620, 0.9721, 0.9638, 0.9924],
    'Specificity': [0.9500, 0.9667, 0.9500, 0.9733, 0.9517, 1.0000],
    'MCC': [0.9000, 0.9168, 0.9168, 0.9601, 0.9326, 0.9833]
}

# Create DataFrame for the comparison
df_comparison = pd.DataFrame(data)

# Display the table
print(df_comparison)

# Plotting a comparison bar chart
fig, ax = plt.subplots(figsize=(10, 6))

# Plot each metric
df_comparison.set_index('Model').plot(kind='bar', ax=ax, colormap='viridis', width=0.8)

# Add labels and title
plt.title('Model Performance Comparison')
plt.xlabel('Model')
plt.ylabel('Score')
plt.xticks(rotation=45, ha='right')

# Display legend on the side
plt.legend(title='Metrics', bbox_to_anchor=(1.05, 0.5), loc='center left')

plt.tight_layout()

# Show the plot
plt.show()
