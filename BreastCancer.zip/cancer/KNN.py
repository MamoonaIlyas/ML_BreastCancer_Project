import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import cross_validate
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc, matthews_corrcoef
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve, roc_auc_score
from sklearn.metrics import ConfusionMatrixDisplay

# Step 1: Load the balanced dataset after feature selection
df = pd.read_csv("Balanced_CancerData.csv")

# Step 2: Features selected after feature selection (these should match the features you selected)
selected_features = [
    'texture_mean', 'concavity_mean', 'concave points_mean', 'area_se',
    'radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst',
    'concavity_worst', 'concave points_worst'
]

# Step 3: Separate features and target
X = df[selected_features]  # Use only the selected features
y = df['diagnosis']  # Target variable

# Step 4: Define KNN model (you can experiment with the value of k)
model = KNeighborsClassifier(n_neighbors=5)

# Step 5: Metrics to evaluate
scoring = ['accuracy', 'precision', 'recall', 'f1']

# Step 6: Apply 10-fold cross-validation
scores = cross_validate(model, X, y, cv=10, scoring=scoring)

# Step 7: Print cross-validation results
print("KNN Model - 10-Fold Cross-Validation Results")
for metric in scoring:
    print(f"{metric.capitalize()}: {scores[f'test_{metric}'].mean():.4f}")

# Step 8: Train the model on the entire dataset
model.fit(X, y)

# Step 9: Predict on the dataset (you can modify this for a train-test split)
y_pred = model.predict(X)

# Step 10: Generate confusion matrix
cm = confusion_matrix(y, y_pred)
print("\nConfusion Matrix:\n", cm)

# Visualize confusion matrix
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Benign (0)", "Malignant (1)"])
disp.plot(cmap='Purples')  
plt.title("KNN - Confusion Matrix")
plt.show()

# Extract TP, TN, FP, FN from confusion matrix
tn, fp, fn, tp = cm.ravel()

# Calculate metrics
specificity = tn / (tn + fp)
npv = tn / (tn + fn)
fpr_metric = fp / (fp + tn)
fnr_metric = fn / (fn + tp)

# Display the additional metrics
print(f"\nSpecificity: {specificity:.4f}")
print(f"Negative Predictive Value (NPV): {npv:.4f}")
print(f"False Positive Rate (FPR): {fpr_metric:.4f}")
print(f"False Negative Rate (FNR): {fnr_metric:.4f}")

# Step 11: Show classification report
print("\nClassification Report:\n", classification_report(y, y_pred))

# Step 12: Plot ROC Curve
fpr, tpr, _ = roc_curve(y, model.predict_proba(X)[:, 1])
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('KNN - ROC Curve')
plt.legend(loc='lower right')
plt.show()

# Step 13: Plot Precision-Recall curve
precision, recall, _ = precision_recall_curve(y, model.predict_proba(X)[:, 1])

plt.figure()
plt.plot(recall, precision, color='b', lw=2)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('KNN - Precision-Recall Curve')
plt.show()

# Step 14: Compute Matthews Correlation Coefficient (MCC)
mcc = matthews_corrcoef(y, y_pred)
print("\nMatthews Correlation Coefficient (MCC):", mcc)
