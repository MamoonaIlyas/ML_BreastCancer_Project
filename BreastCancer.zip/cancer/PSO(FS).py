# === 1. Import Libraries ===
import pandas as pd
import numpy as np
import warnings
import matplotlib.pyplot as plt
from sklearn.exceptions import ConvergenceWarning
from pyswarms.discrete import BinaryPSO
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, matthews_corrcoef

# Ignore convergence warnings
warnings.filterwarnings("ignore", category=ConvergenceWarning)

# === 2. Load and Preprocess Data ===
data = pd.read_csv("Balanced_CancerData.csv")

# Separate features and target
X = data.drop(columns=['diagnosis'])  # Replace with correct target column if needed
y = data['diagnosis']

# Standardize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# === 3. Feature Selection Using Binary PSO ===

# Define objective function for PSO
def objective_function(mask):
    losses = []
    for m in mask:
        if np.count_nonzero(m) == 0:
            losses.append(1)
            continue
        selected_X = X_scaled[:, m == 1]
        clf = MLPClassifier(hidden_layer_sizes=(13,), max_iter=1000, early_stopping=True, random_state=42)
        score = cross_val_score(clf, selected_X, y, cv=5, scoring='accuracy')
        losses.append(1 - score.mean())
    return np.array(losses)

# PSO configuration
options = {'c1': 2, 'c2': 2, 'w': 0.9, 'k': 5, 'p': 2}
dimensions = X_scaled.shape[1]
optimizer = BinaryPSO(n_particles=20, dimensions=dimensions, options=options)

# Run PSO optimization
cost, pos = optimizer.optimize(objective_function, iters=30)

# Get selected feature indices
selected_features = np.where(pos == 1)[0]
print("Selected feature indices:", selected_features)

# Apply feature selection
X_selected = X_scaled[:, selected_features]

# === 4. Model Training Using ANN (with selected features) ===

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)

# Train MLPClassifier (ANN)
final_model = MLPClassifier(hidden_layer_sizes=(13,), max_iter=1000, early_stopping=True, random_state=42)
final_model.fit(X_train, y_train)

# Predictions
y_pred = final_model.predict(X_test)

# === 5. Evaluation Metrics ===
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
accuracy = (tp + tn) / (tp + tn + fp + fn)
sensitivity = tp / (tp + fn)
specificity = tn / (tn + fp)
precision = tp / (tp + fp)
npv = tn / (tn + fn)
fpr = fp / (fp + tn)
fnr = fn / (fn + tp)
f1 = 2 * (precision * sensitivity) / (precision + sensitivity)
mcc = matthews_corrcoef(y_test, y_pred)

# Print metrics
print(f"\n Accuracy: {accuracy:.4f}")
print(f"Sensitivity (Recall): {sensitivity:.4f}")
print(f" Specificity: {specificity:.4f}")
print(f" Precision: {precision:.4f}")
print(f" NPV: {npv:.4f}")
print(f" FPR: {fpr:.4f}")
print(f" FNR: {fnr:.4f}")
print(f" F1 Score: {f1:.4f}")
print(f" MCC: {mcc:.4f}")

# === 6. === FUTURE WORK: Graphical Representation of Evaluation Metrics ===
# You can mention this part is a future addition or enhancement to visualize results.

# Example metric values (Replace with actual ones if needed)
metrics = {
    'Accuracy': accuracy,
    'Sensitivity': sensitivity,
    'Specificity': specificity,
    'Precision': precision,
    'NPV': npv,
    'FPR': fpr,
    'FNR': fnr,
    'F1 Score': f1,
    'MCC': mcc
}

# Color map for each metric (for legend clarity)
colors = {
    'Accuracy': 'green',
    'Sensitivity': 'red',
    'Specificity': 'dodgerblue',
    'Precision': 'black',
    'NPV': 'gold',
    'FPR': 'saddlebrown',
    'FNR': 'sandybrown',
    'F1 Score': 'lightgray',
    'MCC': 'dimgray'
}

# Plotting the metrics
fig, ax = plt.subplots(figsize=(10, 6))
bars = ax.bar(metrics.keys(), metrics.values(), color=[colors[key] for key in metrics.keys()])

# Add text labels
for bar in bars:
    height = bar.get_height()
    ax.annotate(f'{height:.2f}', xy=(bar.get_x() + bar.get_width() / 2, height),
                xytext=(0, 3), textcoords="offset points",
                ha='center', va='bottom')

# Final touches
plt.title("Evaluation Metrics for Hybrid PSO + ANN Model")
plt.ylabel("Score")
plt.ylim(0, 1.1)
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()
