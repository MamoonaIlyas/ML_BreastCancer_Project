import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, cross_validate
from sklearn.metrics import (
    confusion_matrix, classification_report, ConfusionMatrixDisplay,
    roc_curve, auc, precision_recall_curve, matthews_corrcoef
)

# Step 1: Load preprocessed dataset
df = pd.read_csv("Balanced_CancerData.csv")

# Step 2: Use only selected features after Feature Selection (from RFE output)
# Assuming 'selected_features' contains the list of features selected by RFE
selected_features = ['texture_mean', 'concavity_mean', 'concave points_mean', 'area_se', 
                     'radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst', 
                     'concavity_worst', 'concave points_worst']  # Adjust this as per your RFE output

# Separate features and target
X = df[selected_features]  # Only the selected features
y = df['diagnosis']

# === PART 1: 10-Fold Cross-Validation ===
print("=== Logistic Regression - 10-Fold Cross-Validation Results ===")
model_cv = LogisticRegression(max_iter=1000)
scoring = ['accuracy', 'precision', 'recall', 'f1']
scores = cross_validate(model_cv, X, y, cv=10, scoring=scoring)
for metric in scoring:
    print(f"{metric.capitalize()}: {scores[f'test_{metric}'].mean():.4f}")

# === PART 2: Train-Test Split Evaluation ===
# Step 3: Train-test split (80/20)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Step 4: Train logistic regression model
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# Step 5: Predictions
y_pred = model.predict(X_test)
y_pred_prob = model.predict_proba(X_test)[:, 1]

# Step 6: Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print("\n=== Confusion Matrix ===\n", cm)

# Step 7: Classification Report
print("\n=== Classification Report ===\n", classification_report(y_test, y_pred))

# Step 8: Extra Metrics
tn, fp, fn, tp = cm.ravel()
specificity = tn / (tn + fp)
npv = tn / (tn + fn)
fpr = fp / (fp + tn)
fnr = fn / (fn + tp)
mcc = matthews_corrcoef(y_test, y_pred)

print(f"Specificity: {specificity:.4f}")
print(f"Negative Predictive Value (NPV): {npv:.4f}")
print(f"False Positive Rate (FPR): {fpr:.4f}")
print(f"False Negative Rate (FNR): {fnr:.4f}")
print(f"Matthews Correlation Coefficient (MCC): {mcc:.4f}")

# === PART 3: Visualizations ===

# Confusion Matrix Plot
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Benign (0)", "Malignant (1)"])
disp.plot(cmap='Blues')
plt.title("Logistic Regression - Confusion Matrix")
plt.show()

# ROC Curve
fpr_vals, tpr_vals, _ = roc_curve(y_test, y_pred_prob)
roc_auc = auc(fpr_vals, tpr_vals)

plt.figure()
plt.plot(fpr_vals, tpr_vals, color='darkorange', lw=2, label=f'ROC Curve (AUC = {roc_auc:.4f})')
plt.plot([0, 1], [0, 1], color='navy', linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Logistic Regression - ROC Curve')
plt.legend(loc='lower right')
plt.grid(True)
plt.show()

# Precision-Recall Curve
precision, recall, _ = precision_recall_curve(y_test, y_pred_prob)
pr_auc = auc(recall, precision)

plt.figure()
plt.plot(recall, precision, color='green', lw=2, label=f'PR Curve (AUC = {pr_auc:.4f})')
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Logistic Regression - Precision-Recall Curve')
plt.legend(loc='lower left')
plt.grid(True)
plt.show()
