import pandas as pd

# Create a performance summary table
data = {
    "Model": ["ANN", "KNN", "SVM", "Random Forest", "Logistic Regression"],
    "Accuracy": [0.97, 0.97, 0.94, 0.96, 0.96],
    "Precision": [0.95, 0.97, 0.86, 0.90, 0.95],
    "Recall": [0.95, 0.91, 0.90, 0.95, 0.90],
    "F1 Score": [0.95, 0.94, 0.88, 0.93, 0.92],
    "ROC AUC": [0.991, 1.00, 0.9900, 0.9933, 0.9771],  
    "MCC": [0.9333, 0.9179, 0.8365, 0.9021, 0.8988]
}

df_summary = pd.DataFrame(data)

# Save to CSV
csv_path = r"D:\studies\Mamoona\Mamoona B(SE)\Semester_6\ML_ProjectCancer\cancer\Performance_Summary.csv"
df_summary.to_csv(csv_path, index=False)

print(df_summary.head())


