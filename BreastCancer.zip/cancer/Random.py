import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_validate
from sklearn.metrics import (
    confusion_matrix, classification_report, ConfusionMatrixDisplay,
    matthews_corrcoef, roc_curve, auc, precision_recall_curve
)

# Load the balanced dataset after feature selection
df = pd.read_csv("Balanced_CancerData.csv")

# Features selected after feature selection (using RFE or other methods)
selected_features = [
    'texture_mean', 'concavity_mean', 'concave points_mean', 'area_se',
    'radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst',
    'concavity_worst', 'concave points_worst'
]

# Separate features and target
X = df[selected_features]  # Use only selected features
y = df['diagnosis']  # Target variable

# === 10-Fold Cross-Validation ===
print("=== Random Forest - 10-Fold Cross-Validation Results ===")
model_cv = RandomForestClassifier(random_state=42)
scoring = ['accuracy', 'precision', 'recall', 'f1']
scores = cross_validate(model_cv, X, y, cv=10, scoring=scoring)
for metric in scoring:
    print(f"{metric.capitalize()}: {scores[f'test_{metric}'].mean():.4f}")

# === Train-Test Split Evaluation ===
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)
y_pred_prob = model.predict_proba(X_test)[:, 1]

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print("\n=== Confusion Matrix ===\n", cm)

# Classification Report
print("\n=== Classification Report ===\n", classification_report(y_test, y_pred))

# Extract TN, FP, FN, TP
tn, fp, fn, tp = cm.ravel()

# Compute Additional Metrics
specificity = tn / (tn + fp)
npv = tn / (tn + fn)
fpr = fp / (fp + tn)
fnr = fn / (fn + tp)
mcc = matthews_corrcoef(y_test, y_pred)

# Display Additional Metrics
print(f"Specificity: {specificity:.4f}")
print(f"Negative Predictive Value (NPV): {npv:.4f}")
print(f"False Positive Rate (FPR): {fpr:.4f}")
print(f"False Negative Rate (FNR): {fnr:.4f}")
print(f"Matthews Correlation Coefficient (MCC): {mcc:.4f}")

# === Visualizations ===

# Confusion Matrix Plot
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Benign (0)", "Malignant (1)"])
disp.plot(cmap='Greens')
plt.title("Random Forest - Confusion Matrix")
plt.show()

# ROC Curve
fpr_vals, tpr_vals, _ = roc_curve(y_test, y_pred_prob)
roc_auc = auc(fpr_vals, tpr_vals)

plt.figure()
plt.plot(fpr_vals, tpr_vals, color='darkorange', lw=2, label=f'ROC Curve (AUC = {roc_auc:.4f})')
plt.plot([0, 1], [0, 1], color='navy', linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Random Forest - ROC Curve')
plt.legend(loc='lower right')
plt.grid(True)
plt.show()

# Precision-Recall Curve
precision, recall, _ = precision_recall_curve(y_test, y_pred_prob)
pr_auc = auc(recall, precision)

plt.figure()
plt.plot(recall, precision, color='blue', lw=2, label=f'PR Curve (AUC = {pr_auc:.4f})')
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Random Forest - Precision-Recall Curve')
plt.legend(loc='lower left')
plt.grid(True)
plt.show()
