# Import libraries
import pandas as pd
import numpy as np
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import LabelEncoder, StandardScaler


# Load the dataset
df = pd.read_csv("CancerData.csv")  # Use your file path here

# Step 1: Drop unnecessary columns (ID, unnamed)
df.drop(columns=['id', 'Unnamed: 32'], errors='ignore', inplace=True)

# Step 2: Handle missing values - replace with mean (numeric columns)
df.fillna(df.mean(numeric_only=True), inplace=True)

# Step 3: Encode the target variable 'diagnosis' (B=0, M=1)
if 'diagnosis' in df.columns:
    le = LabelEncoder()
    df['diagnosis'] = le.fit_transform(df['diagnosis'])

# Step 4: Remove outliers using IQR (on numeric columns)
Q1 = df.quantile(0.25)
Q3 = df.quantile(0.75)
IQR = Q3 - Q1
df = df[~((df < (Q1 - 1.5 * IQR)) | (df > (Q3 + 1.5 * IQR))).any(axis=1)]

# Step 5: Normalize features using StandardScaler
X = df.drop('diagnosis', axis=1)
y = df['diagnosis']

#scaler = MinMaxScaler()

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step 6.5: Balance the data using SMOTE
sm = SMOTE(random_state=42)
X_resampled, y_resampled = sm.fit_resample(X_scaled, y)

# Optional: Save resampled data
df_balanced = pd.DataFrame(X_resampled, columns=X.columns)
df_balanced['diagnosis'] = y_resampled
df_balanced.to_csv("Balanced_CancerData.csv", index=False)

# Step 6: Create final DataFrame and add the target variable back
df_cleaned = pd.DataFrame(X_scaled, columns=X.columns)
df_cleaned['diagnosis'] = y.values

# Step 7: Save the cleaned data to a new CSV
df_cleaned.to_csv("PreprocessCancerData.csv", index=False)
print(" Preprocessing complete. File saved as: CancerDataPreprocess.csv")
